=====================
Python-PDFKit authors
=====================

* `Stanislav Golovanov <https://github.com/JazzCore>`_


Contributors
------------

* `Tomscytale <https://github.com/tomscytale>`_
* `Matheus Marchini <https://github.com/mmarchini>`_
* `Rory McCann <https://github.com/rory>`_
